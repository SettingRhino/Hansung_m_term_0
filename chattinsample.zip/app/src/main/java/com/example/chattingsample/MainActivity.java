package com.example.chattingsample;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private EditText editText;
    private ListView listView;

    private ArrayList<String> list = new ArrayList<>();
    private ArrayAdapter<String> arrayAdapter;

    private String name, chat_msg, chat_user;
    private DatabaseReference reference = FirebaseDatabase.getInstance()
            .getReference().child("ChattingRooms").child(findRoom());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.list);
        button = (Button) findViewById(R.id.button);
        editText = (EditText) findViewById(R.id.editText);
        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(arrayAdapter);
        name = "Guest " + new Random().nextInt(1000);
        //ex) name = user.getName();
        //여기 부분에서 닉네임을 불러올것
        button.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {

                Map<String, Object> map = new HashMap<String, Object>();

                String key = reference.push().getKey();
                reference.updateChildren(map);

                DatabaseReference root = reference.child(key);

                Map<String, Object> objectMap = new HashMap<String, Object>();

                objectMap.put("name", name);
                objectMap.put("text", editText.getText().toString());

                root.updateChildren(objectMap);
                editText.setText("");
            }
        });

        reference.addChildEventListener(new ChildEventListener() {
            @Override public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                chatConversation(dataSnapshot);
            }

            @Override public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                chatConversation(dataSnapshot);
            }

            @Override public void onChildRemoved(DataSnapshot dataSnapshot) {
                chatConversation(dataSnapshot);
            }

            @Override public void onChildMoved(DataSnapshot dataSnapshot, String s) {
                chatConversation(dataSnapshot);
            }

            @Override public void onCancelled(DatabaseError databaseError) {

            }
        });
        //파이어베이스의 데이터 값에 변동이 생겨 각각의 이벤트가 발생 하는 경우 다시 텍스트 뷰에 붙이 arrayadapter가 작동하게 설정
    }

    private void chatConversation(DataSnapshot dataSnapshot) {
        Iterator i = dataSnapshot.getChildren().iterator();

        while (i.hasNext()) {
            chat_user = (String) ((DataSnapshot) i.next()).getValue();
            chat_msg = (String) ((DataSnapshot) i.next()).getValue();

            arrayAdapter.add(chat_user + " : " + chat_msg);
        }
        arrayAdapter.notifyDataSetChanged();
    }
    //파이어 베이스에서 데이터를 받아와 이터레터를 이용하여 화면의 arrayAdapter에 띄우는 부분

    public String findRoom(){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("ChattingRooms");
        //채팅방이 모여있는 노드?의 래퍼런스를 받아온다.
        int user1 =2, user2 = 3;
        String RoomNum = "";
        if(user1 > user2){
            RoomNum =  Integer.toString(user1) + "00" + Integer.toString(user2);
        }
        else{
            RoomNum =  Integer.toString(user2) + "00" + Integer.toString(user1);
        }
        return RoomNum;
        //고유 아이디넘버를 받아서 방번호를 배정 user1 00 user2 (아이디 중 큰 값이 무조건 앞으로 오게)
        //방번호를 배정하는 함수

    }
}