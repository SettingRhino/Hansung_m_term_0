package seven.hansung.nonamed;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import seven.hansung.nonamed.utility.BoardSearchSpinner;
import seven.hansung.nonamed.utility.Spinnercreat;

public class PostWrite extends AppCompatActivity {
    protected Spinner spinner;
    protected Spinnercreat spinnercraet;
    protected ArrayAdapter<CharSequence> spinerAdapter;
    protected EditText tx_write_title;
    protected EditText tx_write_content;
    protected CheckBox isnoname;
    protected Button bt_write_ok;
    String tmp_share;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.post_write);
            init();



        }

        protected void init(){
            //스피너처리
            spinnercraet=new Spinnercreat();
            spinner = findViewById(R.id.post_select_board);
            spinerAdapter=spinnercraet.creatAdapter(spinerAdapter,R.array.post_select_board,this);
            spinner.setAdapter(spinerAdapter);
            spinner.setOnItemSelectedListener( Spinner_select);

            tx_write_title=findViewById(R.id.tx_write_title);
            tx_write_content=findViewById(R.id.tx_write_content);
            isnoname=findViewById(R.id.isnoname);
            bt_write_ok=findViewById(R.id.bt_write_ok);
            bt_write_ok.setOnClickListener(listen_ok);

        }
        View.OnClickListener listen_ok=new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isnoname.isChecked()){
                    tmp_share="true";
                }
                else
                    tmp_share="false";
                Toast.makeText(getApplicationContext(),spinner.getSelectedItem().toString()+
                                tx_write_title.getText().toString()+
                                tx_write_content.getText().toString()+
                                tmp_share,Toast.LENGTH_SHORT).show();
            }
        };
        //스피너 선택시.
    AdapterView.OnItemSelectedListener Spinner_select=new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        }
        @Override
        public void onNothingSelected(AdapterView<?> parent) {
            Toast.makeText(getApplicationContext(),"--",Toast.LENGTH_SHORT).show();
        }
    };

}