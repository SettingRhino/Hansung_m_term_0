package seven.hansung.nonamed;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Chatting_Main extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chatting_main);
    }
}
