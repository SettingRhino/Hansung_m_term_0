package seven.hansung.nonamed;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class One_on_one_Chatting extends AppCompatActivity {

    private Button button,exit_btn;
    private EditText editText;
    private ListView listView;
    private TextView userNickname;

    private ArrayList<String> list = new ArrayList<>();
    private ArrayAdapter<String> arrayAdapter;

    private String name, chat_msg, chat_user;
    private DatabaseReference reference;

    @Override
    public void onBackPressed(){
        // 뒤로가기 막음
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one_on_one__chatting);
        Intent intent = getIntent();
        String str = intent.getStringExtra("RoomName");
        String userName = intent.getStringExtra("userName");
        reference = FirebaseDatabase.getInstance().getReference().child("ChattingRooms").child(str);
        listView = (ListView) findViewById(R.id.list);
        button = (Button) findViewById(R.id.button);
        exit_btn = (Button)findViewById(R.id.exit_btn);
        editText = (EditText) findViewById(R.id.editText);
        userNickname = (TextView)findViewById(R.id.userNickname);
        userNickname.setText(userName);
        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(arrayAdapter);
        name = userName;
        //ex) name = user.getName();
        //여기 부분에서 닉네임을 불러올것
        button.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {

                Map<String, Object> map = new HashMap<String, Object>();

                String key = reference.push().getKey();
                reference.updateChildren(map);

                DatabaseReference root = reference.child(key);

                Map<String, Object> objectMap = new HashMap<String, Object>();

                objectMap.put("name", name);
                objectMap.put("text", editText.getText().toString());

                root.updateChildren(objectMap);
                editText.setText("");
            }
        });

        exit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        reference.addChildEventListener(new ChildEventListener() {
            @Override public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                chatConversation(dataSnapshot);
            }

            @Override public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                chatConversation(dataSnapshot);
            }

            @Override public void onChildRemoved(DataSnapshot dataSnapshot) {
                chatConversation(dataSnapshot);
            }

            @Override public void onChildMoved(DataSnapshot dataSnapshot, String s) {
                chatConversation(dataSnapshot);
            }

            @Override public void onCancelled(DatabaseError databaseError) {

            }
        });
        //파이어베이스의 데이터 값에 변동이 생겨 각각의 이벤트가 발생 하는 경우 다시 텍스트 뷰에 붙이 arrayadapter가 작동하게 설정
    }

    private void chatConversation(DataSnapshot dataSnapshot) {
        Iterator i = dataSnapshot.getChildren().iterator();

        while (i.hasNext()) {
            chat_user = (String) ((DataSnapshot) i.next()).getValue();
            chat_msg = (String) ((DataSnapshot) i.next()).getValue();

            arrayAdapter.add(chat_user + " : " + chat_msg);
        }
        arrayAdapter.notifyDataSetChanged();
    }
    //파이어 베이스에서 데이터를 받아와 이터레터를 이용하여 화면의 arrayAdapter에 띄우는 부분

}

