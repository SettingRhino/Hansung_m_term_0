package seven.hansung.nonamed;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ChattingRoomSelect extends AppCompatActivity {
    ListView listView;
    List clist = new ArrayList<>();
    ArrayAdapter CArrayAdapter;
    Button mkRoom;
    String userID = "null";

    DatabaseReference reference = FirebaseDatabase.getInstance().getReference("ChattingRooms");
    DatabaseReference Uref = FirebaseDatabase.getInstance().getReference("user");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatting_room_select);
        Intent intent = getIntent();
        final String userName = intent.getStringExtra("username");
        mkRoom = (Button)findViewById(R.id.mkroom);
        mkRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ChattingRoomSelect.this);
                LayoutInflater inflater = getLayoutInflater();
                View layout = inflater.inflate(R.layout.mkroom,null);
                builder.setView(layout);
                final EditText userid = (EditText)layout.findViewById(R.id.userid);
                builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                      reference.addListenerForSingleValueEvent(new ValueEventListener() {
                          String roomnamef = userid.getText().toString() + "00" + userName;
                          String roomnameb = userName + "00" + userid.getText().toString();
                          @Override
                          public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                              for (DataSnapshot fileSnapshot : dataSnapshot.getChildren()){
                                  String str = fileSnapshot.getKey();
                                  if(str.equals(roomnamef)){
                                      Intent intent = new Intent(ChattingRoomSelect.this, One_on_one_Chatting.class);
                                      intent.putExtra("RoomName",roomnamef);
                                      intent.putExtra("userName",userName);
                                      startActivity(intent);
                                  }
                                  else if(str.equals(roomnameb)){
                                      Intent intent = new Intent(ChattingRoomSelect.this, One_on_one_Chatting.class);
                                      intent.putExtra("RoomName",roomnameb);
                                      intent.putExtra("userName",userName);
                                      startActivity(intent);
                                  }
                                  else{
                                      Uref.addListenerForSingleValueEvent(new ValueEventListener() {
                                          @Override
                                          public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                              for (DataSnapshot fileSnapshot : dataSnapshot.getChildren()){
                                                  String str = fileSnapshot.getKey();
                                                  if((str.equals(userid.getText().toString()))){
                                                      Intent intent = new Intent(ChattingRoomSelect.this, One_on_one_Chatting.class);
                                                      intent.putExtra("RoomName",userid.getText().toString() + "00" + userName);
                                                      intent.putExtra("userName",userName);
                                                      startActivity(intent);
                                                  }
                                              }
                                              Toast.makeText(getApplicationContext(),"해당닉넴을 가진 유저가 없습니다.",Toast.LENGTH_SHORT).show();
                                          }

                                          @Override
                                          public void onCancelled(@NonNull DatabaseError databaseError) {

                                          }
                                      });
                                  }
                              }
                          }

                          @Override
                          public void onCancelled(@NonNull DatabaseError databaseError) {

                          }
                      });
                      //final String roomname2 = userName + "00" + userid.getText().toString();
                      //Intent intent0 = new Intent(getApplicationContext(), One_on_one_Chatting.class);
                      //intent0.putExtra("RoomName",roomname);
                      //intent0.putExtra("userName",userName);
                      //startActivity(intent0);

                    }
                });
                builder.setNegativeButton(android.R.string.cancel, null);
                builder.create().show();
            }
        });
        listView = (ListView) findViewById(R.id.roomselect);
        CArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,clist);
        listView.setAdapter(CArrayAdapter);
       // reference.addListenerForSingleValueEvent();
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // 클래스 모델이 필요?
                clist.clear();
                for (DataSnapshot fileSnapshot : dataSnapshot.getChildren()) {
                    String str = fileSnapshot.getKey().toString(), userID="22";
                    String[] arr = str.split("00");
                    if(userName.equals(arr[0])){
                       clist.add(arr[1]);
                    }
                    else if(userName.equals(arr[1])){
                      clist.add(arr[0]);
                    }
                 }
                CArrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("TAG: ", "Failed to read value", databaseError.toException());
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final String roomname = clist.get(position).toString();

                reference.addListenerForSingleValueEvent(new ValueEventListener() {
                    String roomnamef = roomname + "00" + userName;
                    String roomnameb = userName + "00" + roomname;
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot fileSnapshot : dataSnapshot.getChildren()){
                            String str = fileSnapshot.getKey();
                            if(str.equals(roomnamef)){
                                Intent intent = new Intent(ChattingRoomSelect.this, One_on_one_Chatting.class);
                                intent.putExtra("RoomName",roomnamef);
                                intent.putExtra("userName",userName);
                                startActivity(intent);
                            }
                            else if(str.equals(roomnameb)){
                                Intent intent = new Intent(ChattingRoomSelect.this, One_on_one_Chatting.class);
                                intent.putExtra("RoomName",roomnameb);
                                intent.putExtra("userName",userName);
                                startActivity(intent);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

        });

    }

    public void mkIntent(){

    }
}


//
//       추가 설정해야되는것.
//       아이디 받아오기
//       채팅방 만들기 버튼 제작
//

