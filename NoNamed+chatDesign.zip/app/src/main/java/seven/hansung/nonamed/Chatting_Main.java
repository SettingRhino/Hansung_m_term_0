package seven.hansung.nonamed;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Chatting_Main extends AppCompatActivity {
    /*
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chatting_main);
        Intent intent=getIntent();
        username=intent.getStringExtra("username");
    }

     */
    ListView listView;
    List clist = new ArrayList<>();
    ArrayAdapter CArrayAdapter;
    //채팅방 목록을 listview로 띄우는데 필요한것임
    Button mkRoom;
    String token = "";
    //토큰값을 받아오는 String타입 변수
    DatabaseReference reference = FirebaseDatabase.getInstance().getReference("ChattingRooms");
    //채팅룸 객체의 레퍼런스를 받아온다.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatting_room_select);
        Intent intent = getIntent();
        final String userName = intent.getStringExtra("username");
        final String dd = intent.getStringExtra("ttoken");
        //인텐트에서 받아온 값을 저장한다.
        mkRoom = (Button)findViewById(R.id.mkroom);
        //채팅방을 만드는 버튼임
        mkRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //채팅방을 새로 만드는 부분에 관한 코드
                AlertDialog.Builder builder = new AlertDialog.Builder(Chatting_Main.this);
                LayoutInflater inflater = getLayoutInflater();
                View layout = inflater.inflate(R.layout.mkroom,null);
                builder.setView(layout);
                //AlertDialog를 통해 상대 유저의 닉네임을 받아온다.
                final EditText userid = (EditText)layout.findViewById(R.id.userid);
                builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    //String token = "";
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        DatabaseReference tokenRef = FirebaseDatabase.getInstance().getReference().child("user").getRef();
                        tokenRef.orderByChild("nickname").equalTo(userid.getText().toString()).addListenerForSingleValueEvent(new ValueEventListener() {

                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                for(DataSnapshot dataSnapshot0 : dataSnapshot.getChildren()){
                                    Object str = dataSnapshot0.child("pushToken").getValue();
                                    token = str.toString();
                                    //토큰값을 받아온당
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }

                        });
                        //채팅방이 만들어질때 상대 유저의 토큰값(pushToken)을 받아서 넘겨줘야 해서 추가한 부분

                        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ChattingRooms");
                        ref.addListenerForSingleValueEvent(new ValueEventListener() {
                            String roomnamef = userid.getText().toString() + "00" + userName;
                            String roomnameb = userName + "00" + userid.getText().toString();
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                for (DataSnapshot fileSnapshot : dataSnapshot.getChildren()){
                                    String str = fileSnapshot.getKey();
                                    if(str.equals(roomnamef)){
                                        Log.i("ttokken", " " + token);
                                        Intent intent = new Intent(Chatting_Main.this, One_on_one_Chatting.class);
                                        intent.putExtra("RoomName",roomnamef);
                                        intent.putExtra("userName",userName);
                                        intent.putExtra("token",token);
                                        startActivity(intent);
                                    }
                                    else if(str.equals(roomnameb)){
                                        Log.i("ttokken", " " + token);
                                        Intent intent = new Intent(Chatting_Main.this, One_on_one_Chatting.class);
                                        intent.putExtra("RoomName",roomnameb);
                                        intent.putExtra("userName",userName);
                                        intent.putExtra("token",token);
                                        startActivity(intent);
                                    }

                                }
                            }
                            //만약 이미 채팅방이 활성화 되어져 있는 경우 해당 채팅방을 이동하게 구현
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        DatabaseReference Uref = FirebaseDatabase.getInstance().getReference("user");
                        Uref.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                boolean check = true;
                                for (DataSnapshot fileSnapshot : dataSnapshot.getChildren()){
                                    String str = fileSnapshot.child("nickname").getValue().toString();
                                    //String str0 = fileSnapshot.getKey().toString();
                                    if(str.equals(userid.getText().toString())){
                                        check = false;
                                    }
                                }
                                if(check)
                                    Toast.makeText(getApplicationContext(),"해당닉넴을 가진 유저가 없습니다.",Toast.LENGTH_SHORT).show();
                                else{
                                    Intent intent = new Intent(Chatting_Main.this, One_on_one_Chatting.class);
                                    intent.putExtra("RoomName",userid.getText().toString() + "00" + userName);
                                    intent.putExtra("userName",userName);
                                    intent.putExtra("token",token);
                                    startActivity(intent);
                                }
                            }
                            //만약 활성 채팅방이 없고 닉네임이 없는 닉네임이면 토스트를 띄우고 아니면 방을 만든다.
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }

                });
                builder.setNegativeButton(android.R.string.cancel, null);
                //다이얼로그의 취소버튼 구현
                builder.create().show();
            }
        });
        listView = (ListView) findViewById(R.id.roomselect);
        CArrayAdapter = new ArrayAdapter<String>(this, R.layout.chatlistlayout, clist);//android.R.layout.simple_list_item_1,clist);
        listView.setAdapter(CArrayAdapter);
        //리스트 뷰임(방의 목록을 담은)
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // 클래스 모델이 필요?
                clist.clear();
                for (DataSnapshot fileSnapshot : dataSnapshot.getChildren()) {
                    String str = fileSnapshot.getKey().toString();
                    String[] arr = str.split("00");
                    if(userName.equals(arr[0])){
                        clist.add(arr[1]);
                    }
                    else if(userName.equals(arr[1])){
                        clist.add(arr[0]);
                    }
                }
                CArrayAdapter.notifyDataSetChanged();
            }
            //firebase에서 전체목록을 가져오고 유저 닉네임과 일치하는 항목만 가져옴
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("TAG: ", "Failed to read value", databaseError.toException());
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            //  Intent intent = new Intent(ChattingRoomSelect.this, One_on_one_Chatting.class);

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final Intent intent00 = new Intent(Chatting_Main.this, One_on_one_Chatting.class);
                final String roomname = clist.get(position).toString();
                Log.i("ttokken", " 0 : " + roomname);
                DatabaseReference tokenRef = FirebaseDatabase.getInstance().getReference().child("user").getRef();
                tokenRef.orderByChild("nickname").equalTo(roomname).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot dataSnapshot0 : dataSnapshot.getChildren()){
                            Object str = dataSnapshot0.child("pushToken").getValue();
                            token = str.toString();
                            Log.i("ttokken", " 1 : " + token);
                        }
                        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ChattingRooms");
                        ref.addListenerForSingleValueEvent(new ValueEventListener() {
                            String roomnamef = roomname + "00" + userName;
                            String roomnameb = userName + "00" + roomname;

                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                for (DataSnapshot fileSnapshot : dataSnapshot.getChildren()){
                                    String str = fileSnapshot.getKey();
                                    if(str.equals(roomnamef)){

                                        Intent intent00 = new Intent(Chatting_Main.this, One_on_one_Chatting.class);
                                        intent00.putExtra("RoomName",roomnamef);
                                        intent00.putExtra("userName",userName);
                                        intent00.putExtra("token",token);
                                        startActivity(intent00);
                                    }
                                    else if(str.equals(roomnameb)){

                                        Intent intent00 = new Intent(Chatting_Main.this, One_on_one_Chatting.class);
                                        intent00.putExtra("RoomName",roomnameb);
                                        intent00.putExtra("userName",userName);
                                        intent00.putExtra("token",token);
                                        startActivity(intent00);
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }

                });
                //리스트뷰에 클릭리스너를 달아서 클릭시 해당 방으로 이동(인텐트를 만듬)

            }

        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                //롱클릭시 다이얼로그를 띄우고 다이얼로그에서 삭제할지 아닐지 여부를 선택
                final String roomname = clist.get(position).toString();
                AlertDialog.Builder builder = new AlertDialog.Builder(Chatting_Main.this);
                builder.setTitle("채팅방 삭제").setMessage("정말 삭제하겠습니까?");
                builder.setPositiveButton("삭제", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int id)
                    {
                        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ChattingRooms");
                        ref.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String roomnamef = roomname + "00" + userName;
                                String roomnameb = userName + "00" + roomname;
                                for (DataSnapshot fileSnapshot : dataSnapshot.getChildren()){
                                    String str = fileSnapshot.getKey();
                                    if(str.equals(roomnamef)){
                                        reference.child(roomnamef).setValue(null);
                                        // CArrayAdapter.notifyDataSetChanged();
                                    }
                                    else if(str.equals(roomnameb)){
                                        reference.child(roomnamef).setValue(null);
                                        //CArrayAdapter.notifyDataSetChanged();
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                });

                builder.setNegativeButton("취소", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int id)
                    {
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                return true;
            }
        });


    }
}
