package seven.hansung.nonamed;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.telecom.Call;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.common.api.Response;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import seven.hansung.nonamed.Model.NotificationModel;

public class One_on_one_Chatting extends AppCompatActivity {

    private Button button,exit_btn; //text전송하는 버튼 , 인텐트 종료 버튼
    private EditText editText; // 전송할 텍스트를 받아오는 editText
    private ListView listView; //텍스트를 띄우는 리스트뷰
    private TextView userNickname; // 상단에 유저의 닉네임을 띄우는 textview
    private ArrayList<String> list = new ArrayList<>(); //텍스트를 띄울때 쓰는 리스트
    private ArrayAdapter<String> arrayAdapter; //리스트에 쓰는 어답터
    private String name, chat_msg, chat_user;// 파이어베이스의 이터레이터에서 받은 값을 여기에 임시저장하고 텍스트뷰에 띄움
    private DatabaseReference reference; //
    public String token;

    //for image profile
    ImageView imageView;
    DatabaseReference database;
    DatabaseReference userref;
    StorageReference imageref;

    @Override
    public void onBackPressed(){
        Toast.makeText(getApplicationContext(),"종료버튼을 통해 채팅을 종료해주세요",Toast.LENGTH_SHORT).show();
        //뒤로가기 버튼을 쓰면 이상한 버그가 떠서 뒤로가기 버튼 막고 종료버튼을 통해서 종료를 하도록 강제함
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one_on_one__chatting);
        Intent intent = getIntent();//selecmenu에서 여기로 넘어올때 넘겨받은 값을 받기위해 사용함
        String str = intent.getStringExtra("RoomName");
        final String userName = intent.getStringExtra("userName");
        token = intent.getStringExtra("token");
        final String dd = intent.getStringExtra("ttoken");
        //인텐트에서 넘겨받은 내용을 받아와서 저장한다.
        reference = FirebaseDatabase.getInstance().getReference().child("ChattingRooms").child(str);
        //해당 채팅방의 레퍼런스를 받아온다.
        listView = (ListView) findViewById(R.id.list);
        button = (Button) findViewById(R.id.button);
        exit_btn = (Button)findViewById(R.id.exit_btn);
        editText = (EditText) findViewById(R.id.editText);
        userNickname = (TextView)findViewById(R.id.userNickname);
        //xml에서 만든 뷰 컨텐츠들을 받아온다.
        userNickname.setText(userName);
        //상대 닉네임을 받아서 적는다.
        arrayAdapter = new ArrayAdapter<String>(this, R.layout.chatlistlayout, list);
        listView.setAdapter(arrayAdapter);
        name = userName;

        //userref
        imageView = findViewById(R.id.avatar);
        database = FirebaseDatabase.getInstance().getReference();
        userref = database.child("user").getRef();

        // 리스트뷰를 설정한다.
        button.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                pushAlarm(token);
                Map<String, Object> map = new HashMap<String, Object>();
                String key = reference.push().getKey();
                reference.updateChildren(map);
                DatabaseReference root = reference.child(key);
                Map<String, Object> objectMap = new HashMap<String, Object>();
                objectMap.put("name", name);
                objectMap.put("text", editText.getText().toString());
                root.updateChildren(objectMap);
                //발송버튼을 눌렀을 때, 입력한 값을 해시맵에 저장한 후 해시맵을 통해 파이어베이스에 올린다.

                //토큰값을 입력해서 상대에게 fcm푸시를 발생시키는 함수
                editText.setText("");
                //공란으로 재설정 한다.
            }
        });

        exit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                //종료버튼을 통해서 인텐트를 종료한다.
            }
        });

        reference.addChildEventListener(new ChildEventListener() {
            @Override public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                chatConversation(dataSnapshot);
                //pushAlarm(token);
                //파이어 베이스에서 데이터를 받아와 이터레터를 이용하여 화면의 arrayAdapter에 띄우는 함수를 설정한다.
            }

            @Override public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                chatConversation(dataSnapshot);
                //pushAlarm(token);
            }

            @Override public void onChildRemoved(DataSnapshot dataSnapshot) {
                chatConversation(dataSnapshot);
                //pushAlarm(token);
            }

            @Override public void onChildMoved(DataSnapshot dataSnapshot, String s) {
                chatConversation(dataSnapshot);
            }

            @Override public void onCancelled(DatabaseError databaseError) {

            }
        });
        //파이어베이스의 데이터 값에 변동이 생겨 각각의 이벤트가 발생 하는 경우 다시 텍스트 뷰에 붙이 arrayadapter가 작동하게 설정


        //상대 아바타 불러옴
        userref.orderByChild("nickname").equalTo(userName).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //String tuid="";
                String tname = "";
                String tprofile = "";
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    //Object ouid= snapshot.child("uid").getValue(Object.class);
                    Object oname = snapshot.child("nickname").getValue(Object.class);
                    Object oprofile = snapshot.child("avatar").getValue(Object.class);
                    //tuid = ouid.toString();
                    tname = oname.toString();
                    tprofile = oprofile.toString();
                }
                if(tname.equals(userName)){
                    //textview_id.setText("Welcome, " + tname);
                    FirebaseStorage storage = FirebaseStorage.getInstance();
                    StorageReference storageRef = storage.getReference().child("characterimage");
                    imageref=storageRef.child(tprofile);
                    Glide.with(getApplicationContext() ).load(imageref).into(imageView);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void chatConversation(DataSnapshot dataSnapshot) {
        Iterator i = dataSnapshot.getChildren().iterator();
        while (i.hasNext()) {
            chat_user = (String) ((DataSnapshot) i.next()).getValue();
            chat_msg = (String) ((DataSnapshot) i.next()).getValue();
            arrayAdapter.add(chat_user + " : " + chat_msg);
            //pushAlarm(token);
        }
        arrayAdapter.notifyDataSetChanged();
    }
    //파이어 베이스에서 데이터를 받아와 이터레터를 이용하여 화면의 arrayAdapter에 띄우는 부분

    void pushAlarm(String token){
        Gson gson = new Gson();
        NotificationModel notificationModel = new NotificationModel();
        //notification모델을 정의하고 객체를 생성한다.
        notificationModel.to = token;
        notificationModel.notification.title = "Chatting";
        notificationModel.notification.text = "채팅을 확인하세요!!";
        //정의한 모델에 맞춰서 값을 입력한다.
        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json; charset=utf8"),gson.toJson(notificationModel));
        Request request = new Request.Builder()
                .header("Content-Type","application/json")
                .addHeader("Authorization","key=AIzaSyBaaovsqk2vtpJMshb3fPUlgtaByzcpM-Y")
                .url("https://fcm.googleapis.com/fcm/send")
                .post(requestBody)
                .build();
        //request패킷을 만든다.
        OkHttpClient okHttpClient = new OkHttpClient();
        //okhttp프로토콜을 이용하여
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@org.jetbrains.annotations.NotNull okhttp3.Call call, @org.jetbrains.annotations.NotNull IOException e) {
                Log.i("adadada","fail");
            }

            @Override
            public void onResponse(@org.jetbrains.annotations.NotNull okhttp3.Call call, @org.jetbrains.annotations.NotNull okhttp3.Response response) throws IOException {
                Log.i("adadada","onresponse");
            }
        });

    }

    void sendPostToFCM(String token) {
        final String gettoken = token;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // FMC 메시지 생성 start
                    JSONObject root = new JSONObject();
                    JSONObject notification = new JSONObject();
                    notification.put("body", "Check Chat!");
                    notification.put("title", "Chatting!!");
                    root.put("notification", notification);
                    root.put("to", gettoken);
                    // FMC 메시지 생성 end

                    URL Url = new URL("https://fcm.googleapis.com/fcm/send");
                    HttpURLConnection conn = (HttpURLConnection) Url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setDoInput(true);
                    conn.addRequestProperty("Authorization", "key=" + "AIzaSyBaaovsqk2vtpJMshb3fPUlgtaByzcpM-Y");
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setRequestProperty("Content-type", "application/json");
                    OutputStream os = conn.getOutputStream();
                    os.write(root.toString().getBytes("utf-8"));
                    os.flush();
                    conn.getResponseCode();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }


}
