package seven.hansung.nonamed;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ChattingRoomSelect extends AppCompatActivity {
    ListView listView;
    List clist = new ArrayList<>();
    ArrayAdapter CArrayAdapter;
    private DatabaseReference reference = FirebaseDatabase.getInstance().getReference("ChattingRooms");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatting_room_select);
        listView = (ListView) findViewById(R.id.roomselect);
        CArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,clist);
        listView.setAdapter(CArrayAdapter);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // 클래스 모델이 필요?
                clist.clear();
                for (DataSnapshot fileSnapshot : dataSnapshot.getChildren()) {
                    String str = fileSnapshot.getKey().toString(), userID="3";
                    //userID부분만 상황에 맞게 수정
                    //userID = ref.get....
                    String[] arr = str.split("00");
                    if(userID.equals(arr[0]) || userID.equals(arr[1])){
                        clist.add(str);
                    }
                    /*
                    else if(userID.equals(arr[1])){
                        clist.add(arr[0]);
                    }

                     */
                    //String str = fileSnapshot.getKey().toString();
                    //clist.add(str);
                }
                CArrayAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("TAG: ", "Failed to read value", databaseError.toException());
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ChattingRoomSelect.this, One_on_one_Chatting.class);
                String roomname = clist.get(position).toString();
                intent.putExtra("RoomName",roomname);
                Log.d("asdf"," "+ roomname);
                startActivity(intent);
            }
        });

    }
}


//
//       추가 설정해야되는것.
//       아이디 받아오기
//       채팅방 만들기 버튼 제작
//

